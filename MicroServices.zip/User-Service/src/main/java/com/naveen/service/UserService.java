package com.naveen.service;

import java.util.List;

import com.naveen.entity.User;

public interface UserService {

	User addUser(User user);
	
	List<User> findAll();

	User findById(Integer userid);
	
	User updateUser(User user);
	
	void deleteUser(Integer id);
}
