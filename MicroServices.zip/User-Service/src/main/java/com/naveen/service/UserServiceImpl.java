package com.naveen.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.naveen.entity.User;
import com.naveen.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	
	@Autowired
	private UserRepository userrepo;
	
	@Override
	public User addUser(User user) {
		return userrepo.save(user);
	}

	

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return userrepo.findAll();
	}



	@Override
	public User findById(Integer userid) {
		// TODO Auto-generated method stub
		Optional<User> userDb = this.userrepo.findById(userid);
		
		try {
			return userrepo.findById(userid).get();
		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		}
	}



	@Override
	public User updateUser(User user) {
		// TODO Auto-generated method stub
		Optional<User> userDb = this.userrepo.findById(user.getId());
		
			if(userDb.isPresent()) {
				User userupdate = userDb.get();
				userupdate.setId(user.getId());
				userupdate.setName(user.getName());
				userupdate.setAge(user.getAge());
				userupdate.setAddress(user.getAddress());
				userrepo.save(userupdate);
				return userupdate;
			}
		else {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		}
	}



	@Override
	public void deleteUser(Integer id) {
		// TODO Auto-generated method stub
		Optional<User> userDb = this.userrepo.findById(id);
		
		if(userDb.isPresent()) {
			User userdelete = userDb.get();
			userrepo.delete(userdelete);
		}else {
			System.out.println("User Not Exist");
		}
	}
	
	

}
