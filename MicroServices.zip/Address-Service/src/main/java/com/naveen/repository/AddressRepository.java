package com.naveen.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.naveen.entity.Address;

public interface AddressRepository extends JpaRepository<Address, Integer>{

	@Query(nativeQuery = true, value="SELECT ua.id, ua.lane1, ua.lane2, ua.state, ua.zip FROM project.address ua join project.user u on u.id = ua.id where ua.id=:?;")
	Address findAddressByUserId(@Param("id") Integer userId);
}
