package com.naveen.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.naveen.entity.Address;
import com.naveen.repository.AddressRepository;
import com.naveen.response.AddressResponse;

@Service
public class AddressService {

	@Autowired 
	private AddressRepository addressrepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	public AddressResponse findAddressByUserId(int userId) {
		Address address = addressrepo.findAddressByUserId(userId);
		
		AddressResponse addressResponse = modelMapper.map(address, AddressResponse.class);
		
		return addressResponse;
	}
}
